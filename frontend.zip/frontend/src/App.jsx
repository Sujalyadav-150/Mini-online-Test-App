import { createContext, useContext, useEffect, useState } from "react";
import { Link, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { BookOpen, Clock3, History, LogOut, PlusCircle, Trophy } from "lucide-react";
import api from "./api";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("quiz_user")); } catch { return null; }
  });
  const login = data => {
    localStorage.setItem("quiz_token", data.token);
    localStorage.setItem("quiz_user", JSON.stringify(data.user));
    setUser(data.user);
  };
  const logout = () => {
    localStorage.removeItem("quiz_token"); localStorage.removeItem("quiz_user"); setUser(null);
  };
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}

function Protected({ children, admin = false }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (admin && user.role !== "admin") return <Navigate to="/" replace />;
  return children;
}

function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  return <div className="app-shell">
    <header className="topbar">
      <Link className="brand" to="/"><span className="brand-icon"><BookOpen size={20}/></span>QuizMaster</Link>
      {user && <nav>
        <Link to="/">Dashboard</Link><Link to="/history"><History size={16}/> History</Link>
        {user.role === "admin" && <Link to="/admin"><PlusCircle size={16}/> Admin</Link>}
        <button className="nav-logout" onClick={() => { logout(); navigate("/login"); }}><LogOut size={16}/> Logout</button>
      </nav>}
    </header>
    <main>{children}</main>
    <footer>QuizMaster <span>•</span> Learn, attempt, improve.</footer>
  </div>;
}

function AuthPage({ mode }) {
  const { login } = useAuth(); const location = useLocation(); const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  const isSignup = mode === "signup";
  const change = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async e => {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      if (isSignup) {
        await api.post("/auth/register", form);
        navigate("/login", { replace: true, state: { registered: true } });
      } else {
        const { data } = await api.post("/auth/login", form);
        login(data); navigate("/");
      }
    } catch (err) { setError(err.response?.data?.message || "Something went wrong. Check your API connection."); }
    finally { setBusy(false); }
  };
  return <div className="auth-wrap"><section className="auth-card">
    <div className="eyebrow">YOUR PERSONAL ASSESSMENT SPACE</div><h1>{isSignup ? "Create your account" : "Welcome back"}</h1>
    <p className="muted">{isSignup ? "Sign up to start practicing with timed tests." : "Log in to continue your learning journey."}</p>
    {!isSignup && location.state?.registered && <div className="success">Account created successfully. Please log in.</div>}
    <form onSubmit={submit}>
      {isSignup && <label>Full name<input name="name" value={form.name} onChange={change} placeholder="Your name" required /></label>}
      <label>Email address<input type="email" name="email" value={form.email} onChange={change} placeholder="you@example.com" required /></label>
      <label>Password<input type="password" name="password" value={form.password} onChange={change} placeholder="At least 6 characters" minLength="6" required /></label>
      {error && <div className="alert">{error}</div>}
      <button className="primary full" disabled={busy}>{busy ? "Please wait..." : isSignup ? "Create account" : "Log in"}</button>
    </form>
    <p className="auth-switch">{isSignup ? "Already registered?" : "New to QuizMaster?"} <Link to={isSignup ? "/login" : "/signup"}>{isSignup ? "Log in" : "Create an account"}</Link></p>
  </section></div>;
}

function Dashboard() {
  const { user } = useAuth(); const navigate = useNavigate();
  const [history, setHistory] = useState([]);
  useEffect(() => { api.get("/results/history").then(r => setHistory(r.data.slice(0, 3))).catch(() => {}); }, []);
  return <div className="page">
    <div className="welcome"><div><div className="eyebrow">STUDENT DASHBOARD</div><h1>Ready to test yourself, {user.name.split(" ")[0]}?</h1><p className="muted">A focused 10-minute test is a great way to track what you know.</p></div><div className="welcome-icon"><Trophy size={34}/></div></div>
    <div className="stats-grid"><div className="stat"><span>Test duration</span><strong>10 min</strong><small><Clock3 size={14}/> Countdown enabled</small></div><div className="stat"><span>Questions per test</span><strong>10</strong><small><BookOpen size={14}/> Multiple choice</small></div><div className="stat"><span>Past attempts</span><strong>{history.length}{history.length === 3 ? "+" : ""}</strong><small><History size={14}/> Recent records</small></div></div>
    <section className="panel start-panel"><div><div className="eyebrow">QUICK ASSESSMENT</div><h2>Your next attempt starts here</h2><p className="muted">Answer 10 questions, submit your test, and review every answer.</p><ul className="feature-list"><li>10 questions selected from the question bank</li><li>10-minute timer with automatic submission</li><li>Instant score and answer-by-answer review</li></ul></div><button className="primary start-btn" onClick={() => navigate("/test")}>Start test <span>→</span></button></section>
    {history.length > 0 && <section className="panel"><div className="section-heading"><h2>Recent attempts</h2><Link to="/history">View all</Link></div>{history.map(item => <div className="history-row" key={item._id}><div><strong>{item.score}/{item.totalQuestions} correct</strong><small>{new Date(item.submittedAt).toLocaleString()}</small></div><span className="score-pill">{Math.round(item.score / item.totalQuestions * 100)}%</span></div>)}</section>}
  </div>;
}

function TestPage() {
  const navigate = useNavigate();
  const [test, setTest] = useState(null); const [answers, setAnswers] = useState({});
  const [current, setCurrent] = useState(0); const [seconds, setSeconds] = useState(600);
  const [loading, setLoading] = useState(true); const [error, setError] = useState(""); const [submitting, setSubmitting] = useState(false);
  useEffect(() => { api.post("/results/begin").then(r => setTest(r.data)).catch(e => setError(e.response?.data?.message || "Could not start test")).finally(() => setLoading(false)); }, []);
  const submit = async expired => {
    if (!test || submitting) return;
    setSubmitting(true);
    try {
      const payload = Object.entries(answers).map(([questionId, selectedAnswer]) => ({ questionId, selectedAnswer }));
      const { data } = await api.post("/results/submit", { attemptToken: test.attemptToken, answers: payload });
      sessionStorage.setItem("quiz_last_result", JSON.stringify(data));
      navigate("/result", { state: { result: data } });
    } catch (e) { setError(e.response?.data?.message || "Submission failed. Please try again."); setSubmitting(false); }
  };
  useEffect(() => {
    if (!test || submitting) return;
    const timer = setInterval(() => setSeconds(prev => {
      if (prev <= 1) { clearInterval(timer); submit(true); return 0; }
      return prev - 1;
    }), 1000);
    return () => clearInterval(timer);
  }, [test, submitting]);
  if (loading) return <div className="page"><div className="loading">Preparing your test...</div></div>;
  if (error && !test) return <div className="page"><div className="alert">{error}</div><button className="secondary" onClick={() => navigate("/")}>Back to dashboard</button></div>;
  const q = test.questions[current]; const answered = Object.keys(answers).length;
  const time = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  return <div className="page test-page">
    <div className="test-top"><div><div className="eyebrow">ONLINE ASSESSMENT</div><h1>General knowledge test</h1><p className="muted">Choose one answer for each question.</p></div><div className={`timer ${seconds < 60 ? "urgent" : ""}`}><Clock3 size={18}/><div><small>TIME LEFT</small><strong>{time}</strong></div></div></div>
    <div className="progress-line"><span style={{ width: `${(answered / test.questions.length) * 100}%` }}/></div>
    <div className="test-layout"><section className="panel question-panel">
      <div className="question-meta"><span>QUESTION {current + 1} OF {test.questions.length}</span><span>{q.subject}</span></div>
      <h2>{q.text}</h2>
      <div className="options">{q.options.map((option, index) => <button key={index} className={`option ${answers[q._id] === index ? "selected" : ""}`} onClick={() => setAnswers({ ...answers, [q._id]: index })}><span className="option-letter">{String.fromCharCode(65 + index)}</span>{option}</button>)}</div>
      <div className="question-actions"><button className="secondary" disabled={current === 0} onClick={() => setCurrent(v => v - 1)}>Previous</button><span>{answered} of 10 answered</span>{current < 9 ? <button className="primary" onClick={() => setCurrent(v => v + 1)}>Next question →</button> : <button className="primary" disabled={submitting} onClick={() => submit(false)}>{submitting ? "Submitting..." : "Submit test"}</button>}</div>
      {error && <div className="alert">{error}</div>}
    </section><aside className="panel navigator"><h3>Question navigator</h3><div className="number-grid">{test.questions.map((item, i) => <button key={item._id} className={`${current === i ? "active" : ""} ${answers[item._id] !== undefined ? "done" : ""}`} onClick={() => setCurrent(i)}>{i + 1}</button>)}</div><div className="legend"><span><i className="dot done-dot"/> Answered</span><span><i className="dot"/> Not answered</span></div><button className="submit-wide" disabled={submitting} onClick={() => { if (window.confirm("Submit your test now?")) submit(false); }}>Submit test</button></aside></div>
  </div>;
}

function ResultPage() {
  const navigate = useNavigate();
  const [result, setResult] = useState(() => {
    const fromSession = sessionStorage.getItem("quiz_last_result");
    try { return fromSession ? JSON.parse(fromSession) : null; } catch { return null; }
  });
  if (!result) return <div className="page"><div className="panel"><h2>No result to display</h2><button className="primary" onClick={() => navigate("/")}>Dashboard</button></div></div>;
  return <div className="page">
    <div className="result-hero panel"><div className="result-icon"><Trophy size={30}/></div><div className="eyebrow">TEST COMPLETED</div><h1>Your result is ready</h1><div className="big-score">{result.score}<span> / {result.totalQuestions}</span></div><p className="muted">{result.percentage}% score {result.timeExpired ? "• Submitted when time ran out" : "• Submitted successfully"}</p><button className="primary" onClick={() => navigate("/")}>Back to dashboard</button></div>
    <div className="review-heading"><h2>Answer review</h2><span>{result.details.filter(d => d.isCorrect).length} correct · {result.details.filter(d => !d.isCorrect).length} incorrect</span></div>
    {result.details.map((d, i) => <section className="panel review-card" key={d.questionId}><div className="review-q"><strong>Q{i + 1}. {d.question}</strong><span className={d.isCorrect ? "correct-tag" : "wrong-tag"}>{d.isCorrect ? "Correct" : "Incorrect"}</span></div><div className="review-options">{d.options.map((option, index) => <div key={index} className={`review-option ${index === d.correctAnswer ? "right-answer" : ""} ${index === d.selectedAnswer && !d.isCorrect ? "wrong-answer" : ""}`}><span>{String.fromCharCode(65 + index)}.</span> {option}{index === d.correctAnswer && <b>Correct answer</b>}</div>)}</div>{d.selectedAnswer === null && <p className="muted">You did not answer this question.</p>}{d.explanation && <p className="explanation">{d.explanation}</p>}</section>)}
  </div>;
}

function HistoryPage() {
  const [items, setItems] = useState([]); const [error, setError] = useState("");
  useEffect(() => { api.get("/results/history").then(r => setItems(r.data)).catch(e => setError(e.response?.data?.message || "Could not load history")); }, []);
  return <div className="page"><div className="page-heading"><div className="eyebrow">YOUR PROGRESS</div><h1>Test history</h1><p className="muted">A record of your previous attempts.</p></div><section className="panel">{error && <div className="alert">{error}</div>}{items.length === 0 && !error ? <div className="empty"><History size={30}/><h3>No attempts yet</h3><p className="muted">Your completed tests will appear here.</p></div> : items.map(item => <div className="history-row" key={item._id}><div><strong>{item.score} / {item.totalQuestions} correct</strong><small>{new Date(item.submittedAt).toLocaleString()} {item.timeExpired ? "· Auto-submitted" : ""}</small></div><div className="history-right"><span className="score-pill">{Math.round(item.score / item.totalQuestions * 100)}%</span><Link to={`/result/${item._id}`}>Review</Link></div></div>)}</section></div>;
}

function HistoryResult({ id }) {
  const navigate = useNavigate(); const [result, setResult] = useState(null); const [error, setError] = useState("");
  useEffect(() => { api.get(`/results/${id}`).then(r => setResult(r.data)).catch(e => setError(e.response?.data?.message || "Could not load result")); }, [id]);
  if (error) return <div className="page"><div className="alert">{error}</div></div>;
  if (!result) return <div className="page"><div className="loading">Loading result...</div></div>;
  return <div className="page"><button className="back-link" onClick={() => navigate("/history")}>← Back to history</button><div className="result-hero panel"><div className="eyebrow">PAST ATTEMPT</div><h1>Attempt review</h1><div className="big-score">{result.score}<span> / {result.totalQuestions}</span></div><p className="muted">{result.percentage}% score</p></div>{result.details.map((d, i) => <section className="panel review-card" key={d.questionId}><div className="review-q"><strong>Q{i + 1}. {d.question}</strong><span className={d.isCorrect ? "correct-tag" : "wrong-tag"}>{d.isCorrect ? "Correct" : "Incorrect"}</span></div>{d.options.map((o, j) => <div className={`review-option ${j === d.correctAnswer ? "right-answer" : ""} ${j === d.selectedAnswer && !d.isCorrect ? "wrong-answer" : ""}`} key={j}>{String.fromCharCode(65+j)}. {o}</div>)}{d.explanation && <p className="explanation">{d.explanation}</p>}</section>)}</div>;
}

function AdminPage() {
  const [form, setForm] = useState({ text: "", options: ["", "", "", ""], correctAnswer: 0, subject: "General Knowledge", explanation: "" });
  const [message, setMessage] = useState(""); const [error, setError] = useState("");
  const updateOption = (i, value) => setForm(f => ({ ...f, options: f.options.map((o, index) => index === i ? value : o) }));
  const submit = async e => { e.preventDefault(); setMessage(""); setError(""); try { await api.post("/questions", form); setMessage("Question added successfully."); setForm({ text: "", options: ["", "", "", ""], correctAnswer: 0, subject: "General Knowledge", explanation: "" }); } catch (e) { setError(e.response?.data?.message || "Could not add question"); } };
  return <div className="page"><div className="page-heading"><div className="eyebrow">BONUS FEATURE</div><h1>Question manager</h1><p className="muted">Add questions to the shared test bank.</p></div><form className="panel admin-form" onSubmit={submit}><label>Question<input value={form.text} onChange={e => setForm({ ...form, text: e.target.value })} required /></label>{form.options.map((o, i) => <label>Option {String.fromCharCode(65+i)}<input value={o} onChange={e => updateOption(i, e.target.value)} required /></label>)}<label>Correct answer<select value={form.correctAnswer} onChange={e => setForm({ ...form, correctAnswer: Number(e.target.value) })}>{form.options.map((o, i) => <option value={i}>{String.fromCharCode(65+i)} {o || "(empty option)"}</option>)}</select></label><label>Subject<input value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })}/></label><label>Explanation (optional)<textarea value={form.explanation} onChange={e => setForm({ ...form, explanation: e.target.value })}/></label>{message && <div className="success">{message}</div>}{error && <div className="alert">{error}</div>}<button className="primary">Add question</button></form></div>;
}

function AppRoutes() {
  return <Layout><Routes>
    <Route path="/login" element={<AuthPage mode="login"/>}/><Route path="/signup" element={<AuthPage mode="signup"/>}/>
    <Route path="/" element={<Protected><Dashboard/></Protected>}/>
    <Route path="/test" element={<Protected><TestPage/></Protected>}/>
    <Route path="/result" element={<Protected><ResultPage/></Protected>}/>
    <Route path="/result/:id" element={<Protected><ResultRoute/></Protected>}/>
    <Route path="/history" element={<Protected><HistoryPage/></Protected>}/>
    <Route path="/admin" element={<Protected admin><AdminPage/></Protected>}/>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes></Layout>;
}
import { useParams } from "react-router-dom";
function ResultRoute() { const { id } = useParams(); return <Protected><HistoryResult id={id}/></Protected>; }

export default function App() { return <AuthProvider><AppRoutes/></AuthProvider>; }
