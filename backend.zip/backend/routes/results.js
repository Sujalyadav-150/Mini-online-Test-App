import { Router } from "express";
import mongoose from "mongoose";
import Question from "../models/Question.js";
import Result from "../models/Result.js";
import { protect } from "../middleware/auth.js";

const router = Router();
const TEST_DURATION_MS = 10 * 60 * 1000;

router.post("/start", protect, async (req, res) => {
  try {
    const questions = await Question.aggregate([{ $sample: { size: 10 } }]);
    if (questions.length < 10) return res.status(400).json({ message: "At least 10 questions are required. Ask an admin to seed questions." });
    const startedAt = new Date();
    res.json({
      attemptId: new mongoose.Types.ObjectId().toString(),
      startedAt,
      durationSeconds: 600,
      questions: questions.map(q => ({ _id: q._id, text: q.text, options: q.options, subject: q.subject }))
    });
  } catch { res.status(500).json({ message: "Could not start test" }); }
});

// Start tickets are signed so the server can validate duration and prevent fabricated start times.
import jwt from "jsonwebtoken";
router.post("/begin", protect, async (req, res) => {
  try {
    const questions = await Question.aggregate([{ $sample: { size: 10 } }]);
    if (questions.length < 10) return res.status(400).json({ message: "At least 10 questions are required. Run npm run seed." });
    const startedAt = Date.now();
    const questionIds = questions.map(q => q._id.toString());
    const attemptToken = jwt.sign({ userId: req.user.id, questionIds, startedAt }, process.env.JWT_SECRET, { expiresIn: "20m" });
    res.json({
      attemptToken, startedAt, durationSeconds: 600,
      questions: questions.map(q => ({ _id: q._id, text: q.text, options: q.options, subject: q.subject }))
    });
  } catch { res.status(500).json({ message: "Could not start test" }); }
});

router.post("/submit", protect, async (req, res) => {
  try {
    const { attemptToken, answers } = req.body;
    const attempt = jwt.verify(attemptToken || "", process.env.JWT_SECRET);
    if (attempt.userId !== req.user.id) return res.status(403).json({ message: "This test does not belong to you" });
    if (!Array.isArray(answers)) return res.status(400).json({ message: "Answers must be an array" });
    const elapsed = Date.now() - attempt.startedAt;
    if (elapsed > TEST_DURATION_MS + 30000) {
      // The attempt is still scored; the response marks it as time-expired.
    }
    const questions = await Question.find({ _id: { $in: attempt.questionIds } });
    const answerMap = new Map(answers.map(a => [String(a.questionId), Number(a.selectedAnswer)]));
    const details = attempt.questionIds.map(id => {
      const q = questions.find(item => item._id.toString() === id);
      const selected = answerMap.has(id) ? answerMap.get(id) : null;
      const correct = q && selected === q.correctAnswer;
      return {
        questionId: id, question: q?.text || "Question unavailable",
        options: q?.options || [], selectedAnswer: selected,
        correctAnswer: q?.correctAnswer ?? null, isCorrect: Boolean(correct),
        explanation: q?.explanation || ""
      };
    });
    const score = details.filter(d => d.isCorrect).length;
    const result = await Result.create({
      studentId: req.user._id,
      answers: details.map(d => ({ questionId: d.questionId, selectedAnswer: d.selectedAnswer })),
      score, totalQuestions: details.length,
      startedAt: new Date(attempt.startedAt), submittedAt: new Date(),
      timeExpired: elapsed >= TEST_DURATION_MS
    });
    res.status(201).json({
      resultId: result._id, score, totalQuestions: details.length,
      percentage: Math.round(score / details.length * 100),
      timeExpired: result.timeExpired, details
    });
  } catch (error) {
    res.status(400).json({ message: "Invalid or expired test attempt. Please start a new test." });
  }
});

router.get("/history", protect, async (req, res) => {
  try {
    const results = await Result.find({ studentId: req.user._id }).sort({ submittedAt: -1 }).lean();
    res.json(results.map(r => ({
      _id: r._id, score: r.score, totalQuestions: r.totalQuestions,
      submittedAt: r.submittedAt, timeExpired: r.timeExpired
    })));
  } catch { res.status(500).json({ message: "Could not load history" }); }
});

router.get("/:id", protect, async (req, res) => {
  try {
    const result = await Result.findOne({ _id: req.params.id, studentId: req.user._id });
    if (!result) return res.status(404).json({ message: "Result not found" });
    const questions = await Question.find({ _id: { $in: result.answers.map(a => a.questionId) } });
    const details = result.answers.map(a => {
      const q = questions.find(item => item._id.equals(a.questionId));
      return q ? {
        questionId: q._id, question: q.text, options: q.options,
        selectedAnswer: a.selectedAnswer, correctAnswer: q.correctAnswer,
        isCorrect: a.selectedAnswer === q.correctAnswer, explanation: q.explanation
      } : null;
    }).filter(Boolean);
    res.json({
      resultId: result._id, score: result.score, totalQuestions: result.totalQuestions,
      percentage: Math.round(result.score / result.totalQuestions * 100),
      timeExpired: result.timeExpired, details
    });
  } catch { res.status(400).json({ message: "Invalid result ID" }); }
});

export default router;
