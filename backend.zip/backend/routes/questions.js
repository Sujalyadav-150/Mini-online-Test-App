import { Router } from "express";
import Question from "../models/Question.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();

router.get("/", protect, async (req, res) => {
  try {
    const questions = await Question.aggregate([{ $sample: { size: 10 } }]);
    res.json(questions.map(q => ({
      _id: q._id, text: q.text, options: q.options, subject: q.subject
    })));
  } catch { res.status(500).json({ message: "Could not load questions" }); }
});

router.post("/", protect, adminOnly, async (req, res) => {
  try {
    const { text, options, correctAnswer, explanation, subject } = req.body;
    if (!text?.trim() || !Array.isArray(options) || options.length !== 4 ||
        options.some(o => !String(o).trim()) || !Number.isInteger(correctAnswer) ||
        correctAnswer < 0 || correctAnswer > 3)
      return res.status(400).json({ message: "Provide a question, four options and correctAnswer index (0–3)" });
    const question = await Question.create({ text, options, correctAnswer, explanation, subject });
    res.status(201).json({ message: "Question added", questionId: question._id });
  } catch { res.status(500).json({ message: "Could not add question" }); }
});

export default router;
