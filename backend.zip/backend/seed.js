import "dotenv/config";
import { connectDB } from "./config/db.js";
import Question from "./models/Question.js";

const questions = [
  { text: "Which language runs natively in a web browser?", options: ["Python", "JavaScript", "C", "Java"], correctAnswer: 1, subject: "Programming", explanation: "JavaScript is supported by browsers." },
  { text: "What does HTML stand for?", options: ["HyperText Markup Language", "HighText Machine Language", "HyperTool Multi Language", "Home Tool Markup Language"], correctAnswer: 0, subject: "Web Development", explanation: "HTML structures web content." },
  { text: "Which data structure follows FIFO?", options: ["Stack", "Tree", "Queue", "Graph"], correctAnswer: 2, subject: "Computer Science", explanation: "A queue is First In, First Out." },
  { text: "What is the time complexity of binary search on a sorted array?", options: ["O(n)", "O(log n)", "O(n²)", "O(1)"], correctAnswer: 1, subject: "DSA", explanation: "The search range is halved at each step." },
  { text: "Which SQL command retrieves data?", options: ["UPDATE", "INSERT", "SELECT", "DROP"], correctAnswer: 2, subject: "Database", explanation: "SELECT reads rows from a table." },
  { text: "Which HTTP method is commonly used to create a resource?", options: ["GET", "POST", "DELETE", "HEAD"], correctAnswer: 1, subject: "Web Development", explanation: "POST commonly creates a resource." },
  { text: "What does CSS primarily control?", options: ["Database storage", "Server routing", "Page presentation", "Network security"], correctAnswer: 2, subject: "Web Development", explanation: "CSS styles and lays out web pages." },
  { text: "Which MongoDB format is used to represent documents?", options: ["BSON", "CSV", "XML only", "YAML"], correctAnswer: 0, subject: "Database", explanation: "MongoDB stores documents in BSON." },
  { text: "Which keyword declares a block-scoped variable in JavaScript?", options: ["var", "let", "define", "dim"], correctAnswer: 1, subject: "Programming", explanation: "let and const are block-scoped." },
  { text: "What does API stand for?", options: ["Application Programming Interface", "Applied Program Internet", "Application Process Integration", "Advanced Programming Input"], correctAnswer: 0, subject: "General", explanation: "An API defines how software components communicate." }
];

try {
  await connectDB();
  await Question.deleteMany({});
  await Question.insertMany(questions);
  console.log(`Seeded ${questions.length} questions`);
  process.exit(0);
} catch (error) {
  console.error(error);
  process.exit(1);
}
