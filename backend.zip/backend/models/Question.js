import mongoose from "mongoose";

const questionSchema = new mongoose.Schema({
  text: { type: String, required: true, trim: true },
  options: { type: [String], validate: v => v.length === 4, required: true },
  correctAnswer: { type: Number, required: true, min: 0, max: 3 },
  explanation: { type: String, default: "" },
  subject: { type: String, default: "General Knowledge" }
}, { timestamps: true });

export default mongoose.model("Question", questionSchema);
