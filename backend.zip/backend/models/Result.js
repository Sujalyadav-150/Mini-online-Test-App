import mongoose from "mongoose";

const resultSchema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  answers: [{ questionId: mongoose.Schema.Types.ObjectId, selectedAnswer: Number }],
  score: { type: Number, required: true },
  totalQuestions: { type: Number, required: true },
  startedAt: { type: Date, required: true },
  submittedAt: { type: Date, default: Date.now },
  timeExpired: { type: Boolean, default: false }
}, { timestamps: true });

export default mongoose.model("Result", resultSchema);
